from algorithms.bubble_sort import BubbleSort
from algorithms.binary_search import BinarySearch
from algorithms.counting_sort import CountingSort
from algorithms.exponential_search import ExponentialSearch
from algorithms.fibonacci_search import FibonacciSearch
from algorithms.heap_sort import HeapSort
from algorithms.insertion_sort import InsertionSort
from algorithms.linear_search import LinearSearch
from algorithms.merge_sort import MergeSort
from algorithms.quick_sort import QuickSort
from algorithms.radix_sort import RadixSort
from algorithms.selection_sort import SelectionSort
from algorithms.ternary_search import TernarySearch
import random
import time
import psutil
import os

def get_random_data(size):
    return [random.randint(1, 1000) for _ in range(size)]
#generates an array of 100 random integers

def display_menu():
    print("\nPlease choose an option from the list below:")
    print("1 - Bubble Sort")
    print("2 - Binary Search")
    print("3 - Counting Sort")
    print("4 - Exponential Search")
    print("5 - Fibonacci Search")
    print("6 - Heap Sort")
    print("7 - Insertion Sort")
    print("8 - Linear Search")
    print("9 - Merge Sort")
    print("10 - Quick Sort")
    print("11 - Radix Sort")
    print("12 - Selection Sort")
    print("13 - Ternary Search")
    print("14 - Exit\n")

def get_memory_usage():
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1024 / 1024  #in MegaBytes

def main():
    print("Welcome to the Searching and Sorting Algorithm Performance Tester!")

    choice = input("Would you like to input your own list of integers (1) or generate random integers (2)? ")

    if choice == '1':
        #User inputs their own list
        user_input = input("Enter integers separated by spaces: ")
        data = list(map(int, user_input.split()))
    elif choice == '2':
        # Generate a list of random ints
        num_elements = int(input("Enter the number of random integers (max 2 million): "))
        if num_elements > 2000000:
            print("Maximum allowed is 2 million. Setting to 2 million.")
            num_elements = 2000000
        data = get_random_data(num_elements)
    else:
        print("Invalid choice. Exiting the program.")
        return

    #Initialize objects
    bubble_sort = BubbleSort()
    binary_search = BinarySearch()
    counting_sort = CountingSort()
    exponential_search = ExponentialSearch()
    fibonacci_search = FibonacciSearch()
    heap_sort = HeapSort()
    insertion_sort = InsertionSort()
    linear_search = LinearSearch()
    merge_sort = MergeSort()
    quick_sort = QuickSort()
    radix_sort = RadixSort()
    selection_sort = SelectionSort()
    ternary_search = TernarySearch()

    while True:
        display_menu()
        option = input("Enter your choice (1/2/3/4/5/6/7/8/9/10/11/12/13/14): ")

        memory_before = get_memory_usage()

        if option == '1':
            print("Starting Bubble Sort...")
            start_time = time.time()
            sorted_array = bubble_sort.sort(data.copy())
            end_time = time.time()
            print(f"Sorted Array: {sorted_array[:10]}...")
            print(f"Bubble Sort Time: {end_time - start_time:.6f} seconds")

        elif option == '2':
            if data:
                target = random.choice(data)
                print(f"Searching for {target}...")
                start_time = time.time()
                index = binary_search.search(data, target)
                end_time = time.time()
                if index != -1:
                    print(f"Found {target} at index {index}.")
                else:
                    print(f"{target} was not found.")
                print(f"Binary Search Time: {end_time - start_time:.6f} seconds")
            else:
                print("The list is empty, cannot perform search.")

        elif option == '3':
            print("Starting Counting Sort...")
            start_time = time.time()
            sorted_array = counting_sort.sort(data.copy())
            end_time = time.time()
            print(f"Sorted Array: {sorted_array[:10]}...")
            print(f"Counting Sort Time: {end_time - start_time:.6f} seconds")

        elif option == '4':
            if data:
                target = random.choice(data)
                print(f"Searching for {target}...")
                start_time = time.time()
                index = exponential_search.search(data, target)
                end_time = time.time()
                if index != -1:
                    print(f"Found {target} at index {index}.")
                else:
                    print(f"{target} was not found.")
                print(f"Exponential Search Time: {end_time - start_time:.6f} seconds")
            else:
                print("The list is empty, cannot perform search.")

        elif option == '5':
            if data:
                target = random.choice(data)
                print(f"Searching for {target}...")
                start_time = time.time()
                index = fibonacci_search.search(data, target)
                end_time = time.time()
                if index != -1:
                    print(f"Found {target} at index {index}.")
                else:
                    print(f"{target} was not found.")
                print(f"Fibonacci Search Time: {end_time - start_time:.6f} seconds")
            else:
                print("The list is empty, cannot perform search.")

        elif option == '6':
            print("Starting Heap Sort...")
            start_time = time.time()
            sorted_array = heap_sort.sort(data.copy())
            end_time = time.time()
            print(f"Sorted Array: {sorted_array[:10]}...")
            print(f"Heap Sort Time: {end_time - start_time:.6f} seconds")

        elif option == '7':
            print("Starting Insertion Sort...")
            start_time = time.time()
            sorted_array = insertion_sort.sort(data.copy())
            end_time = time.time()
            print(f"Sorted Array: {sorted_array[:10]}...")
            print(f"Insertion Sort Time: {end_time - start_time:.6f} seconds")

        elif option == '8':
            if data:
                target = random.choice(data)
                print(f"Searching for {target}...")
                start_time = time.time()
                index = linear_search.search(data, target)
                end_time = time.time()
                if index != -1:
                    print(f"Found {target} at index {index}.")
                else:
                    print(f"{target} was not found.")
                print(f"Linear Search Time: {end_time - start_time:.6f} seconds")
            else:
                print("The list is empty, cannot perform search.")

        elif option == '9':
            print("Starting Merge Sort...")
            start_time = time.time()
            sorted_array = merge_sort.sort(data.copy())
            end_time = time.time()
            print(f"Sorted Array: {sorted_array[:10]}...")
            print(f"Merge Sort Time: {end_time - start_time:.6f} seconds")

        elif option == '10':
            print("Starting Quick Sort...")
            start_time = time.time()
            sorted_array = quick_sort.sort(data.copy())
            end_time = time.time()
            print(f"Sorted Array: {sorted_array[:10]}...")
            print(f"Quick Sort Time: {end_time - start_time:.6f} seconds")

        elif option == '11':
            print("Starting Radix Sort...")
            start_time = time.time()
            sorted_array = radix_sort.sort(data.copy())
            end_time = time.time()
            print(f"Sorted Array: {sorted_array[:10]}...")
            print(f"Radix Sort Time: {end_time - start_time:.6f} seconds")

        elif option == '12':
            print("Starting Selection Sort...")
            start_time = time.time()
            sorted_array = selection_sort.sort(data.copy())
            end_time = time.time()
            print(f"Sorted Array: {sorted_array[:10]}...")
            print(f"Selection Sort Time: {end_time - start_time:.6f} seconds")

        elif option == '13':
            if data:
                target = random.choice(data)
                print(f"Searching for {target}...")
                start_time = time.time()
                index = ternary_search.search(data, target)
                end_time = time.time()
                if index != -1:
                    print(f"Found {target} at index {index}.")
                else:
                    print(f"{target} was not found.")
                print(f"Ternary Search Time: {end_time - start_time:.6f} seconds")
            else:
                print("The list is empty, cannot perform search.")

        elif option == '14':
            print("Goodbye! Exiting the program.")
            break

        else:
            print("Invalid option. Please try again.")



        memory_after = get_memory_usage()
        print(f"Memory Usage: {memory_after - memory_before:.6f} MB\n")

        time.sleep(10)

if __name__ == "__main__":
    main()
