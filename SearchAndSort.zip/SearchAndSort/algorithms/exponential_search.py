class ExponentialSearch:
    def search(self, arr, target):
        if arr[0] == target:
            return 0
        i = 1
        while i < len(arr) and arr[i] <= target:
            i *= 2

        return self.binary_search(arr, i // 2, min(i, len(arr) - 1), target)

    def binary_search(self, arr, low, high, target):
        while low <= high:
            mid = (low + high) // 2
            if arr[mid] == target:
                return mid
            elif arr[mid] < target:
                low = mid + 1
            else:
                high = mid - 1
        return -1
